class UncomparableDataSetItemsException(Exception): pass
